﻿namespace Labb_4
{
    public enum Gender
    {
        Male = 1,
        Female = 2,
        NonBinary = 3
    }
}
